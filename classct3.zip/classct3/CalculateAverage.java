class MyThread extends Thread {
    private int[] array;
    private int startIndex;
    private int endIndex;
    private double partialSum;

    public MyThread(int[] array, int startIndex, int endIndex) {
        this.array = array;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.partialSum = 0.0;
    }

    public double getPartialSum() {
        return partialSum;
    }

    @Override
    public void run() {
        for (int i = startIndex; i < endIndex; i++) {
            partialSum += array[i];
        }
    }
}

class CalculateAverage {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int numThreads = 3;
        int arrayLength = array.length;
        MyThread[] threads = new MyThread[numThreads];
        int chunkSize = arrayLength / numThreads;

        // Create threads and assign them their respective chunks of the array
        for (int i = 0; i < numThreads; i++) {
            int startIndex = i * chunkSize;
            int endIndex = (i == numThreads - 1) ? arrayLength : (i + 1) * chunkSize;
            threads[i] = new MyThread(array, startIndex, endIndex);
            threads[i].start();
        }

        // Wait for all threads to finish
        try {
            for (MyThread thread : threads) {
                thread.join();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Calculate the total sum from partial sums of each thread
        double totalSum = 0.0;
        for (MyThread thread : threads) {
            totalSum += thread.getPartialSum();
        }

        // Calculate the average
        double average = totalSum / arrayLength;
        System.out.println("Average: " + average);
    }
}
